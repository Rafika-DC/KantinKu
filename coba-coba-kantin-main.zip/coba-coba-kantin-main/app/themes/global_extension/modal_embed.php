<div id="modal_preview_all" class="preview_modal">
  <span class="modal_preview_close">&times;</span>
  <img class="preview-modal-content showin" id="modal_preview_image">
  <iframe class="preview-modal-content hidin" id="modal_preview_embed" width="656" height="369" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
  <div id="modal_preview_caption"></div>
</div>