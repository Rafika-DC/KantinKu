<div id="loadingModal" class="modal-loading">
  <div class="modal-loading-content">
      <div class="base-spinner">
        <div class="spinner-loader"></div>
      </div>
      <p id="text_loading">Tunggu sebentar...</p>
  </div>
</div>
