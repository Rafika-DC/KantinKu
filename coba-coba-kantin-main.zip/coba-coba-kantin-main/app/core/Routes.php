<?php
    $routes['login'] = 'auth/index';
    $routes['news'] = 'user/news';
    $routes['logout'] = 'auth/logout';
    $routes['pos'] = 'dashboard/pos';
    $routes['profile'] = 'setting/profile';
    

    DEFINE('ROUTER',$routes);
?>